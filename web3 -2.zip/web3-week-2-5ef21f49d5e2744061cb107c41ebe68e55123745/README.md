# web3-week-2
Project from the second Web3 Week (07-aug-23). https://www.luiztools.com.br/w3w

## smart-contract
Our CrypTwitter.sol smart contract.

## dapp
Our CrypTwitter web3 frontend.

Follow me on social networks for more: https://about.me/luiztools

Receive my news on Telegram: https://t.me/luiznews