# web3-week-1
Project from the first Web3 Week (10-apr-23).
https://www.luiztools.com.br/w3w

## smart-contract
Our DonateCrypto.sol smart contract.

## dapp
Our Donate Crypto web3 frontend.

Follow me on social networks for more: https://about.me/luiztools

Receive my news on Telegram: https://t.me/luiznews