# smart-contract

Our Donate Crypto web3 smart contract. Project from Web3 Week: https://www.luiztools.com.br/w3w

## How to Run

1. open https://remix.ethereum.org
2. create a new DonateCrypto.sol file
3. copy and paste the content from repo
4. compile & deploy
5. test

Follow me on social networks for more: https://about.me/luiztools

Receive my news on Telegram: https://t.me/luiznews